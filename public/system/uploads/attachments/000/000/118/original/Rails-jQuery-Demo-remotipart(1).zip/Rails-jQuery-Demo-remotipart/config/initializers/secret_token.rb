# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
JqueryRails::Application.config.secret_token = '14d748ccb7bec478834026d9ccd18693720043771abe1482a5de414d7e5c8e2bd1bff76c5c3fb23f1416cd733621cdf8da87b0ee6921c39af39cf6a71de399ad'
